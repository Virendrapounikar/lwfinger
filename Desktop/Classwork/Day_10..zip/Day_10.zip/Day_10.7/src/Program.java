package p1.p3;
import p1.p2.Complex;
class Program {
    public static void main (String[] args){
        p1.Complex c1 = new p1.Complex();
        c1.printRecord( );

    }
}