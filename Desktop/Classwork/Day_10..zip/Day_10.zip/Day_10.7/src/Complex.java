class Program{
  public static void main(String[] args) {
    float radius = 10;
    float area = (float)( 3.14 * radius * radius);
  System.out.println("Area :   "+area);
  }
}