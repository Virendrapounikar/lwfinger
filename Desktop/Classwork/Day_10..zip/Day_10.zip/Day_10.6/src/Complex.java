package p1;
 public class Complex {
   public void printRecord(){
       System.out.println("Inside printRecord()");
   } 
}