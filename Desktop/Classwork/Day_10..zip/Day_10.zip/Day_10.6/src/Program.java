package p1;
//import p1.Complex;
class Program {
    public static void main (String[] args){
        p1.Complex c1 = new p1.Complex();
        c1.printRecord( );

    }
}