class Program {
    public static void main (String[] args){
        p1.Complex c1 = new p1.Complex();
        c1.printRecord( );

    }
}